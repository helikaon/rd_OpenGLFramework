//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2014 Media Design School
//
// File Name	: CubeApplication.cpp
// Description	: Implements the CCubeApplication class.
// Author		: Rian Drake.
// Mail			: rian.drake@mediadesign.school.nz
//
			
// Library Includes
#include <Windows.h>
			
// Local Includes
#include "CCubeApplication.h"
#include "CBatch.h"
#include "CShaders.h"
#include "CTimer.h"
#include "CBuffer.h"
			
// This Includes

namespace Application
{
	// Static Variables

	// Static Function Prototypes

	// Implementation
	CCubeApplication::CCubeApplication():
		m_f3Eye(0,0,-1)
	{
		m_ppBatches[BATCH_ONE] = 0;
		m_ppBatches[BATCH_TWO] = 0;
	}
			
	CCubeApplication::~CCubeApplication()
	{
		Shutdown();
	}
		
	GLboolean CCubeApplication::Initialise()
	{
		return InitialiseBatch();
	}

	struct TVertex
	{
		TVertex(float _x, float _y)
		{
			pos[0] = _x;
			pos[1] = _y;
		}

		float pos[2];
	};

	// Shader creation helper
	GLuint createShader(GLenum type, const GLchar* src) {
		GLuint shader = glCreateShader(type);
		glShaderSource(shader, 1, &src, nullptr);
		glCompileShader(shader);
		return shader;
	}

	GLboolean CCubeApplication::InitialiseBatch()
	{
		GLfloat points[] = {
			-0.45f, 0.45f,
			0.45f, 0.45f,
			0.45f, -0.45f,
			-0.45f, -0.45f,
		};

		using namespace OpenGL;
		m_ppBatches[BATCH_ONE] = new CBatch;

		m_ppBatches[BATCH_ONE]->Bind();
		{
			m_ppBatches[BATCH_ONE]->AttachShaders(1);

			CShaders* pShaders = m_ppBatches[BATCH_ONE]->GetShaders(0);
			//pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/glsl/cubeshaders_vs.glsl");
			//pShaders->AttachShader(EShaders::SHADERS_GEOMETRY, "data/glsl/cubeshaders_gs.glsl");
			//pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/glsl/cubeshaders_ps.glsl");
			pShaders->AttachShaders("data/glsl/cubeshaders.xml", "vs", "gs", "fs");
			pShaders->LinkProgram();

			m_ppBatches[BATCH_ONE]->AttachBuffers(1);
			CBuffer* pVB = m_ppBatches[BATCH_ONE]->GetBuffers(0);

			pVB->Map(GL_ARRAY_BUFFER, sizeof(points), points, GL_STATIC_DRAW);
		
			pShaders->AttachAttribute("position", 2, GL_FLOAT, sizeof(TVertex), 0, GL_FALSE);
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		m_matMatrices[MATRIX_PROJ] = glm::ortho(0,1920,0,1080);

		return true;
	}

	GLboolean CCubeApplication::Update(GLfloat _fDt)
	{
		return true;
	}

	GLboolean CCubeApplication::Draw()
	{
		m_ppBatches[BATCH_ONE]->DrawBatch(GL_POINTS, 0, 4);
		return true;
	}

	GLvoid CCubeApplication::Shutdown()
	{
		for(GLuint ui = 0; ui < BATCHES_MAX; ++ui)
		{
			delete m_ppBatches[ui];
			m_ppBatches[ui] = 0;
		}
	}

	GLboolean CCubeApplication::Frame(GLfloat _fDt)
	{
		CTimer timer;
		timer.Reset();

		float fFrameTime = 0.0f;

		while(fFrameTime < 0.016666f)
		{
			float dt = (float)timer.GetDeltaTime();
			Update(dt);

			timer.Tick();
			fFrameTime += dt;
		}

		Draw();
		return true;
	}
};