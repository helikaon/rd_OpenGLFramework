//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2014 Media Design School
//
// File Name	: CubeApplication.cpp
// Description	: Implements the CCubeApplication class.
// Author		: Rian Drake.
// Mail			: rian.drake@mediadesign.school.nz
//
			
// Library Includes
#include <Windows.h>
			
// Local Includes
#include "CCubeApplication.h"
#include "CBatch.h"
#include "CShaders.h"
#include "CTimer.h"
#include "CBuffer.h"
			
// This Includes
			
namespace Application
{
	// Static Variables
			
	// Static Function Prototypes
			
	// Implementation
	CCubeApplication::CCubeApplication():
		m_f3Eye(0,0,-1)
	{
		m_ppBatches[BATCH_ONE] = 0;
		m_ppBatches[BATCH_TWO] = 0;
	}
			
	CCubeApplication::~CCubeApplication()
	{
		Shutdown();
	}
		
	GLboolean CCubeApplication::Initialise()
	{
		return InitialiseBatch();
	}

	struct TVertex
	{
		TVertex(float _x, float _y, float _z, float _r, float _g, float _b, float _tx, float _ty)
			: pos(_x, _y, _z), col(_r, _g, _b), tex(_tx, _ty) {}

		glm::vec3 pos;
		glm::vec3 col;
		glm::vec2 tex;
	};

	GLboolean CCubeApplication::InitialiseBatch()
	{
		using namespace OpenGL;

		m_ppBatches[BATCH_ONE] = new CBatch;
		m_ppBatches[BATCH_TWO] = new CBatch;

		GLfloat f = 0.25f;
		
		TVertex vertices[] =
		{
			TVertex(-f, -f, -f,	0,0,0, 0,0),
			TVertex(-f, -f,  f,	0,0,1, 0,1), 
			TVertex(-f,  f, -f,	0,1,0, 1,0), 
			TVertex(-f,  f,  f,	0,1,1, 1,1),  
			TVertex( f, -f, -f,	1,0,0, 0,0), 
			TVertex( f, -f,  f,	1,0,1, 0,1), 
			TVertex( f,  f, -f,	1,1,0, 1,0),
			TVertex( f,  f,  f,	1,1,1, 1,1),
		};
		
		TVertex vertices2[] =
		{
			TVertex(-1.0f, -1.0f, -0.5f, 0,0,0,0,0),
			TVertex(-1.0f,  1.0f, -0.5f, 0,0,0,0,0),
			TVertex( 1.0f, -1.0f, -0.5f, 0,0,0,0,0),
			TVertex( 1.0f,  1.0f, -0.5f, 0,0,0,0,0),
		};

		GLuint elements2[] = { 0,2,1,1,2,3 };

		m_ppBatches[BATCH_ONE]->Bind();
		{
			m_ppBatches[BATCH_ONE]->AttachShaders(1);
			m_ppBatches[BATCH_ONE]->AttachBuffers(1);

			CShaders* pShaders = m_ppBatches[BATCH_ONE]->GetShaders(0);
			CBuffer* pVB = m_ppBatches[BATCH_ONE]->GetBuffers(0);

			pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/source/glsl/cubeshaders_vs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_GEOMETRY, "data/source/glsl/cubeshaders_gs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/source/glsl/cubeshaders_ps.glsl");
			pShaders->LinkProgram();

			pVB->Map(vertices, sizeof(vertices), GL_STATIC_DRAW, GL_ARRAY_BUFFER);
		
			pShaders->AttachAttribute("position", 3, GL_FLOAT, sizeof(TVertex), 0);
			pShaders->AttachAttribute("color", 3, GL_FLOAT, sizeof(TVertex), (GLvoid*)12);
			pShaders->AttachAttribute("texCoord", 2, GL_FLOAT, sizeof(TVertex), (GLvoid*)24);
			pShaders->AttachTexture("data/assets/cat.png");

			pShaders->AttachUniform("matWVP");
			pShaders->AttachUniform("overrideColor");
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		m_ppBatches[BATCH_TWO]->Bind();
		{
			m_ppBatches[BATCH_TWO]->AttachShaders(1);
			m_ppBatches[BATCH_TWO]->AttachBuffers(2);

			CShaders* pShaders = m_ppBatches[BATCH_TWO]->GetShaders(0);
			CBuffer* pVB = m_ppBatches[BATCH_TWO]->GetBuffers(0);
			CBuffer* pIB = m_ppBatches[BATCH_TWO]->GetBuffers(1);

			pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/source/glsl/mirror_vs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/source/glsl/mirror_ps.glsl");
			pShaders->LinkProgram();

			pVB->Map(vertices2, sizeof(vertices2), GL_STATIC_DRAW, GL_ARRAY_BUFFER);
			pIB->Map(elements2, sizeof(elements2), GL_STATIC_DRAW, GL_ELEMENT_ARRAY_BUFFER);
		
			pShaders->AttachAttribute("position", 3, GL_FLOAT, sizeof(TVertex), 0);
			pShaders->AttachAttribute("color", 3, GL_FLOAT, sizeof(TVertex), (GLvoid*)12);

			pShaders->AttachUniform("matWVP");
		}
		m_ppBatches[BATCH_TWO]->Unbind();

		m_matMatrices[MATRIX_PROJ] = glm::perspective(glm::radians(45.f), 800.f/600.f, 0.1f, 1000.0f);

		return true;
	}

	GLboolean CCubeApplication::Update(GLfloat _fDt)
	{
		static float fRadius = 1.0f;
		static float fSpeed = 1.0f;
		static glm::vec3 f3YPR(0,0,0);

		if(GetAsyncKeyState('A') & 0x8000 || GetAsyncKeyState( VK_LEFT) & 0x8000)	f3YPR.x -= 2.0f*_fDt;
		if(GetAsyncKeyState('D') & 0x8000 || GetAsyncKeyState(VK_RIGHT) & 0x8000)	f3YPR.x += 2.0f*_fDt;
		if(GetAsyncKeyState('W') & 0x8000 || GetAsyncKeyState(   VK_UP) & 0x8000)	f3YPR.y -= 2.0f*_fDt;
		if(GetAsyncKeyState('S') & 0x8000 || GetAsyncKeyState( VK_DOWN) & 0x8000)	f3YPR.y += 2.0f*_fDt;
		if(GetAsyncKeyState('Z') & 0x8000)	fRadius -= fSpeed *_fDt;
		if(GetAsyncKeyState('X') & 0x8000)	fRadius += fSpeed *_fDt;

		// Do not allow the radius to reach zero.
		if(fRadius <= 0.0f)
		{
			fRadius += fSpeed * _fDt;
		}

		// Restrict the angle mPhi.
		if( f3YPR.y < 0.1f )        
			f3YPR.y = 0.1f;

		if( f3YPR.y > 3.14f) 
			f3YPR.y = 3.14f;

		// Convert Spherical to Cartesian coordinates: mPhi measured from +y
		// and mTheta measured counterclockwise from -z.
		m_f3Eye.x =  fRadius*sinf(f3YPR.y)*sinf(f3YPR.x);
		m_f3Eye.z = -fRadius*sinf(f3YPR.y)*cosf(f3YPR.x);
		m_f3Eye.y =  fRadius*cosf(f3YPR.y);
		
		m_matMatrices[MATRIX_VIEW] = glm::lookAt(m_f3Eye, glm::vec3(0,0,0), glm::vec3(0,1,0));
		m_matMatrices[MATRIX_WVP] = m_matMatrices[MATRIX_PROJ] * m_matMatrices[MATRIX_VIEW] * m_matMatrices[MATRIX_WORLD];

		float white[] = {1,1,1,1};

		m_ppBatches[BATCH_TWO]->Bind();
		{
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(pShader->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
		}
		m_ppBatches[BATCH_TWO]->Unbind();
		
		m_ppBatches[BATCH_ONE]->Bind();
		{
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(pShader->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		return true;
	}

	GLboolean CCubeApplication::Draw()
	{
		glEnable(GL_STENCIL_TEST);

		// Draw floor
		glStencilFunc(GL_ALWAYS, 1, 0xFF); // Set any stencil to 1
		glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
		glStencilMask(0xFF); // Write to stencil buffer
		glClear(GL_STENCIL_BUFFER_BIT); // Clear stencil buffer (0 by default)
		
		glCullFace(GL_BACK);
		m_ppBatches[BATCH_TWO]->DrawIndexedBatch(GL_TRIANGLES, 6);

		// Draw cube reflection
		glStencilFunc(GL_EQUAL, 1, 0xFF); // Pass test if stencil value is 1
		glStencilMask(0x00); // Don't write anything to stencil buffer
		glDepthMask(GL_TRUE); // Write to depth buffer

		glm::mat4x4 matWorldMirror = glm::scale(glm::translate(m_matMatrices[MATRIX_WORLD], glm::vec3(0,0,-1)), glm::vec3(1,1,-1));

		m_matMatrices[MATRIX_VIEW] = glm::lookAt(m_f3Eye, glm::vec3(0,0,0), glm::vec3(0,1,0));
		m_matMatrices[MATRIX_WVP] = m_matMatrices[MATRIX_PROJ] * m_matMatrices[MATRIX_VIEW] * matWorldMirror;
		
		m_ppBatches[BATCH_ONE]->Bind();
		{
			float f = 0.5f;
			float overrideColor[] = { f,f,f,f };
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(m_ppBatches[BATCH_ONE]->GetShaders(0)->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
			glUniform4fv(pShader->GetUniform("overrideColor"), 1, overrideColor);
		}
		m_ppBatches[BATCH_ONE]->Unbind();
		
		glCullFace(GL_FRONT);
		m_ppBatches[BATCH_ONE]->DrawBatch(GL_POINT, 0, 8);
		
		glDisable(GL_STENCIL_TEST);

		m_matMatrices[MATRIX_VIEW] = glm::lookAt(m_f3Eye, glm::vec3(0,0,0), glm::vec3(0,1,0));
		m_matMatrices[MATRIX_WVP] = m_matMatrices[MATRIX_PROJ] * m_matMatrices[MATRIX_VIEW] * m_matMatrices[MATRIX_WORLD];

		m_ppBatches[BATCH_ONE]->Bind();
		{
			float f = 1.0f;
			float overrideColor[] = { f,f,f,f };
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(m_ppBatches[BATCH_ONE]->GetShaders(0)->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
			glUniform4fv(pShader->GetUniform("overrideColor"), 1, overrideColor);
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		glClear(GL_DEPTH_BUFFER_BIT);
		
		glCullFace(GL_BACK);
		m_ppBatches[BATCH_ONE]->DrawBatch(GL_POINT, 0, 8);

		glCullFace(GL_FRONT);
		m_ppBatches[BATCH_TWO]->DrawIndexedBatch(GL_TRIANGLES, 6);

		return true;
	}

	GLvoid CCubeApplication::Shutdown()
	{
		for(GLuint ui = 0; ui < BATCHES_MAX; ++ui)
		{
			delete m_ppBatches[ui];
			m_ppBatches[ui] = 0;
		}
	}

	GLboolean CCubeApplication::Frame(GLfloat _fDt)
	{
		CTimer timer;
		timer.Reset();

		float fFrameTime = 0.0f;

		while(fFrameTime < 0.016666f)
		{
			float dt = (float)timer.GetDeltaTime();
			Update(dt);

			timer.Tick();
			fFrameTime += dt;
		}

		Draw();
		return true;
	}
};