//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2014 Media Design School
//
// File Name	: CubeApplication.cpp
// Description	: Implements the CCubeApplication class.
// Author		: Rian Drake.
// Mail			: rian.drake@mediadesign.school.nz
//
			
// Library Includes
			
// Local Includes
#include "CCubeApplication.h"
#include "CBatch.h"
#include "CShaders.h"
#include "CBuffer.h"
			
// This Includes
			
namespace Application
{
	// Static Variables
			
	// Static Function Prototypes
			
	// Implementation
	CCubeApplication::CCubeApplication():
		m_f3Eye(0,0,-1)
	{
		m_ppBatches[BATCH_ONE] = 0;
		m_ppBatches[BATCH_TWO] = 0;
	}
			
	CCubeApplication::~CCubeApplication()
	{
		Shutdown();
	}
		
	GLboolean CCubeApplication::Initialise()
	{
		return InitialiseBatch();
	}

	GLboolean CCubeApplication::InitialiseBatch()
	{
		using namespace OpenGL;

		m_ppBatches[BATCH_ONE] = new CBatch;
		m_ppBatches[BATCH_TWO] = new CBatch;

		GLfloat f = 0.25f;
		GLfloat o = 2;
		
		GLfloat vertices[] =
		{
			-f, -f, -f,	0,0,0, 0,0, 
			-f, -f,  f,	0,0,1, 0,1, 
			-f,  f, -f,	0,1,0, 1,0, 
			-f,  f,  f,	0,1,1, 1,1,  
			 f, -f, -f,	1,0,0, 0,0, 
			 f, -f,  f,	1,0,1, 0,1, 
			 f,  f, -f,	1,1,0, 1,0,
			 f,  f,  f,	1,1,1, 1,1, 
		};
		
		GLfloat vertices2[] =
		{
			-1.0f, -1.0f, -0.5f, 0.0f, 0.0f, 0.0f,
			-1.0f,  1.0f, -0.5f, 0.0f, 0.0f, 0.0f,
			 1.0f, -1.0f, -0.5f, 0.0f, 0.0f, 0.0f,
			 1.0f,  1.0f, -0.5f, 0.0f, 0.0f, 0.0f,
		};

		GLuint elements[] =
		{
			// FRONT
			0,2,4,
			4,2,6,
			
			// BACK
			1,5,3,
			3,5,7,
			
			// LEFT
			1,3,0,
			0,3,2,
			
			// RIGHT
			4,6,5,
			5,6,7,

			// TOP
			2,3,6,
			6,3,7,

			// BOTTOM
			0,4,1,
			1,4,5,
		};

		GLuint elements2[] =
		{
			// FRONT
			0,2,1,
			1,2,3
		};

		m_ppBatches[BATCH_ONE]->Bind();
		{
			m_ppBatches[BATCH_ONE]->AttachShaders(1);
			m_ppBatches[BATCH_ONE]->AttachBuffers(2);

			CShaders* pShaders = m_ppBatches[BATCH_ONE]->GetShaders(0);
			CBuffer* pVB = m_ppBatches[BATCH_ONE]->GetBuffers(0);
			CBuffer* pIB = m_ppBatches[BATCH_ONE]->GetBuffers(1);

			pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/source/glsl/cubeshaders_vs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/source/glsl/cubeshaders_ps.glsl");
			pShaders->LinkProgram();

			pVB->Map(vertices, sizeof(vertices), GL_STATIC_DRAW, GL_ARRAY_BUFFER);
			pIB->Map(elements, sizeof(elements), GL_STATIC_DRAW, GL_ELEMENT_ARRAY_BUFFER);
		
			pShaders->AttachAttribute("position", 3, GL_FLOAT, 8*sizeof(GLfloat), 0, false);
			pShaders->AttachAttribute("color", 3, GL_FLOAT, 8*sizeof(GLfloat), (GLvoid*)(sizeof(GLfloat)*3), false);
			pShaders->AttachAttribute("texcoord", 2, GL_FLOAT, 8*sizeof(GLfloat), (GLvoid*)(sizeof(GLfloat)*2), false);

			pShaders->AttachUniform("matWVP");
			pShaders->AttachUniform("colorOverride");
			pShaders->AttachTexture("data/assets/cat.png");
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		m_ppBatches[BATCH_TWO]->Bind();
		{
			m_ppBatches[BATCH_TWO]->AttachShaders(1);
			m_ppBatches[BATCH_TWO]->AttachBuffers(2);

			CShaders* pShaders = m_ppBatches[BATCH_TWO]->GetShaders(0);
			CBuffer* pVB = m_ppBatches[BATCH_TWO]->GetBuffers(0);
			CBuffer* pIB = m_ppBatches[BATCH_TWO]->GetBuffers(1);

			pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/source/glsl/mirror_vs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/source/glsl/mirror_ps.glsl");
			pShaders->LinkProgram();

			pVB->Map(vertices2, sizeof(vertices2), GL_STATIC_DRAW, GL_ARRAY_BUFFER);
			pIB->Map(elements2, sizeof(elements2), GL_STATIC_DRAW, GL_ELEMENT_ARRAY_BUFFER);
		
			pShaders->AttachAttribute("position", 3, GL_FLOAT, 6*sizeof(GLfloat), 0, false);
			pShaders->AttachAttribute("color", 3, GL_FLOAT, 6*sizeof(GLfloat), (GLvoid*)(sizeof(GLfloat)*3), false);

			pShaders->AttachUniform("matWVP");
		}
		m_ppBatches[BATCH_TWO]->Unbind();

		m_matMatrices[MATRIX_PROJ] = glm::perspective(glm::radians(45.f), 800.f/600.f, 0.1f, 1000.0f);

		return true;
	}

	GLboolean CCubeApplication::Update(GLfloat _fDt)
	{
		static GLfloat frame = 0.0f;
		frame += _fDt;

		m_f3Eye.x = sin(frame) * 5;
		m_f3Eye.y = sin(frame) * 5;
		m_f3Eye.z = cos(frame) * 5;
		
		m_matMatrices[MATRIX_VIEW] = glm::lookAt(m_f3Eye, glm::vec3(0,0,0), glm::vec3(0,1,0));
		m_matMatrices[MATRIX_WVP] = m_matMatrices[MATRIX_PROJ] * m_matMatrices[MATRIX_VIEW] * m_matMatrices[MATRIX_WORLD];

		float white[] = {1,1,1,1};

		m_ppBatches[BATCH_TWO]->Bind();
		{
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(pShader->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
		}
		m_ppBatches[BATCH_TWO]->Unbind();
		
		m_ppBatches[BATCH_ONE]->Bind();
		{
			auto pShader = m_ppBatches[BATCH_ONE]->GetShaders(0);
			glUniformMatrix4fv(pShader->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
			glUniform4fv(pShader->GetUniform("override"), 1, white);
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		return true;
	}

	GLboolean CCubeApplication::Draw()
	{
		m_ppBatches[BATCH_ONE]->DrawIndexedBatch(GL_TRIANGLES, 36);

		glEnable(GL_STENCIL_TEST);

		// Draw floor
		glStencilFunc(GL_ALWAYS, 1, 0xFF); // Set any stencil to 1
		glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
		glStencilMask(0xFF); // Write to stencil buffer
		glDepthMask(GL_FALSE); // Don't write to depth buffer
		glClear(GL_STENCIL_BUFFER_BIT); // Clear stencil buffer (0 by default)

		
		m_ppBatches[BATCH_TWO]->DrawIndexedBatch(GL_TRIANGLES, 6);

		// Draw cube reflection
		glStencilFunc(GL_EQUAL, 1, 0xFF); // Pass test if stencil value is 1
		glStencilMask(0x00); // Don't write anything to stencil buffer
		glDepthMask(GL_TRUE); // Write to depth buffer

		glm::mat4x4 matWorldMirror = glm::scale(glm::translate(m_matMatrices[MATRIX_WORLD], glm::vec3(0,0,-1)), glm::vec3(1,1,-1));

		m_matMatrices[MATRIX_VIEW] = glm::lookAt(m_f3Eye, glm::vec3(0,0,0), glm::vec3(0,1,0));
		m_matMatrices[MATRIX_WVP] = m_matMatrices[MATRIX_PROJ] * m_matMatrices[MATRIX_VIEW] * matWorldMirror;
		
		m_ppBatches[BATCH_ONE]->Bind();
		glUniformMatrix4fv(m_ppBatches[BATCH_ONE]->GetShaders(0)->GetUniform("matWVP"), 1, false, glm::value_ptr(m_matMatrices[MATRIX_WVP]));
		m_ppBatches[BATCH_ONE]->Unbind();
		
		m_ppBatches[BATCH_ONE]->DrawIndexedBatch(GL_TRIANGLES, 36);

		
		glDisable(GL_STENCIL_TEST);

		return true;
	}

	GLvoid CCubeApplication::Shutdown()
	{
		for(GLuint ui = 0; ui < BATCHES_MAX; ++ui)
		{
			delete m_ppBatches[ui];
			m_ppBatches[ui] = 0;
		}
	}

	GLboolean CCubeApplication::Frame(GLfloat _fDt)
	{
		Update(_fDt);
		Draw();
		return true;
	}
};