//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2014 Media Design School
//
// File Name	: CTexture.cpp
// Description	: Implements the CTexture class.
// Author		: Rian Drake.
// Mail			: rian.drake@mediadesign.school.nz
//
			
// Library Includes
			
// Local Includes
#include "CTexture.h"
			
// This Includes

namespace OpenGL
{	
	// Static Variables
				
	// Static Function Prototypes
				
	// Implementation
	CTexture::CTexture()
		: m_glTexture(0)
	{
				
	}
				
	CTexture::~CTexture()
	{
		glDeleteTextures(1, &m_glTexture);
	}

	GLvoid CTexture::Initialise(const GLchar* _pcFilename)
	{
		glBindTexture(GL_TEXTURE_2D, m_glTexture);
		//m_glTexture = SOIL_load_OGL_texture(_pcFilename, SOIL_LOAD_RGBA, 0, 0);
	}

	GLuint CTexture::GetTexture()
	{
		return m_glTexture;
	}
};
