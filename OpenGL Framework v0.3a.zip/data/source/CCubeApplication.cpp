//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2014 Media Design School
//
// File Name	: CubeApplication.cpp
// Description	: Implements the CCubeApplication class.
// Author		: Rian Drake.
// Mail			: rian.drake@mediadesign.school.nz
//
			
// Library Includes
#include <Windows.h>
			
// Local Includes
#include "CCubeApplication.h"
#include "CBatch.h"
#include "CShaders.h"
#include "CTimer.h"
#include "CBuffer.h"
			
// This Includes
			
namespace Application
{
	// Static Variables
			
	// Static Function Prototypes
			
	// Implementation
	CCubeApplication::CCubeApplication():
		m_f3Eye(0,0,-1)
	{
		m_ppBatches[BATCH_ONE] = 0;
		m_ppBatches[BATCH_TWO] = 0;
	}
			
	CCubeApplication::~CCubeApplication()
	{
		Shutdown();
	}
		
	GLboolean CCubeApplication::Initialise()
	{
		return InitialiseBatch();
	}

	struct TVertex
	{
		TVertex(float _x, float _y)
			: pos(_x, _y) {}

		glm::vec2 pos;
	};

	GLboolean CCubeApplication::InitialiseBatch()
	{
		using namespace OpenGL;

		m_ppBatches[BATCH_ONE] = new CBatch;

		GLfloat f = 0.25f;
		
		TVertex vertices[] =
		{
			TVertex(-f, -f),
			TVertex(-f, -f), 
			TVertex(-f,  f), 
			TVertex(-f,  f),
		};

		m_ppBatches[BATCH_ONE]->Bind();
		{
			m_ppBatches[BATCH_ONE]->AttachShaders(1);
			m_ppBatches[BATCH_ONE]->AttachBuffers(1);

			CShaders* pShaders = m_ppBatches[BATCH_ONE]->GetShaders(0);
			CBuffer* pVB = m_ppBatches[BATCH_ONE]->GetBuffers(0);

			pShaders->AttachShader(EShaders::SHADERS_VERTEX, "data/source/glsl/cubeshaders_vs.glsl");
			pShaders->AttachShader(EShaders::SHADERS_FRAGMENT, "data/source/glsl/cubeshaders_ps.glsl");
			pShaders->LinkProgram();

			pVB->Map(vertices, sizeof(vertices), GL_STATIC_DRAW, GL_ARRAY_BUFFER);
		
			pShaders->AttachAttribute("position", 2, GL_FLOAT, sizeof(TVertex), 0);
		}
		m_ppBatches[BATCH_ONE]->Unbind();

		m_matMatrices[MATRIX_PROJ] = glm::perspective(glm::radians(45.f), 800.f/600.f, 0.1f, 1000.0f);

		return true;
	}

	GLboolean CCubeApplication::Update(GLfloat _fDt)
	{
		return true;
	}

	GLboolean CCubeApplication::Draw()
	{
		
		m_ppBatches[BATCH_ONE]->DrawBatch(GL_LINES, 0, 4);

		return true;
	}

	GLvoid CCubeApplication::Shutdown()
	{
		for(GLuint ui = 0; ui < BATCHES_MAX; ++ui)
		{
			delete m_ppBatches[ui];
			m_ppBatches[ui] = 0;
		}
	}

	GLboolean CCubeApplication::Frame(GLfloat _fDt)
	{
		CTimer timer;
		timer.Reset();

		float fFrameTime = 0.0f;

		while(fFrameTime < 0.016666f)
		{
			float dt = (float)timer.GetDeltaTime();
			Update(dt);

			timer.Tick();
			fFrameTime += dt;
		}

		Draw();
		return true;
	}
};